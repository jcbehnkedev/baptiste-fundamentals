# Additional Requirements

You will need to install some additional libraries for this and the following sections: numpy, scipy, pandas, matplotlib, and mplfinance.

You can either install them manually using `pip install numpy`, etc, or use the
provided `requirements.txt` file located here, using `pip install -r requirements.txt`.
